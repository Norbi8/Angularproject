import {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
} from "./chunk-DPCDX6LF.js";
import "./chunk-WL33QOM5.js";
import "./chunk-VHXX53IH.js";
import "./chunk-7VKTOJ56.js";
import "./chunk-XSVUB2TB.js";
import "./chunk-AR2SKMNP.js";
export {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
};
//# sourceMappingURL=@angular_fire_compat.js.map
