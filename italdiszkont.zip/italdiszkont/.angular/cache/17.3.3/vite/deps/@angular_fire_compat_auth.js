import {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
} from "./chunk-DY2BEBUR.js";
import "./chunk-FSLZPE4G.js";
import "./chunk-Q6SZW4WA.js";
import "./chunk-DPCDX6LF.js";
import "./chunk-WL33QOM5.js";
import "./chunk-KE6TMBIG.js";
import "./chunk-APKX25FU.js";
import "./chunk-PKYOT43P.js";
import "./chunk-VHXX53IH.js";
import "./chunk-7VKTOJ56.js";
import "./chunk-XSVUB2TB.js";
import "./chunk-AR2SKMNP.js";
export {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
};
//# sourceMappingURL=@angular_fire_compat_auth.js.map
