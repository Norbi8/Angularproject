export interface Drink {
    alkohol:number;
    ar:number;
    id:string;
    imgurl:string;
    leiras:string;
    nev:string;
    tipus:string;
}
