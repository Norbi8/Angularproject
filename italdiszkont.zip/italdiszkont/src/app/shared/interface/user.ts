export interface User {
    email:string;
    id:string;
}
