import { HufseparatorPipe } from './hufseparator.pipe';

describe('HufseparatorPipe', () => {
  it('create an instance', () => {
    const pipe = new HufseparatorPipe();
    expect(pipe).toBeTruthy();
  });
});
