export const environment = {
    production: false,
    firebase: {
      apiKey: "AIzaSyDlPdWLxGKRvCDnS77MLXNLoZabKHbQSg8",
      authDomain: "italdiszkont-afc3a.firebaseapp.com",
      projectId: "italdiszkont-afc3a",
      storageBucket: "italdiszkont-afc3a.appspot.com",
      messagingSenderId: "975238435836",
      appId: "1:975238435836:web:635ae04264f694253b5879",
      measurementId: "G-ECPKYTWLDN"
    }
  };